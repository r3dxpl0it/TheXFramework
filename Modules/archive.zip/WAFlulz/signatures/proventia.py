#!/usr/bin/env python

#Not functional

#def fingerprint(req):
	#instantiate product
	#product = None
	#invoke waf_payloads.py
	#follow redirection
	
	#retval = re.search(r"/Admin_Files/", req])
	
    #If value was returned, identify WAF
	#if retval:
	#	product = "Proventia Web Application Security (IBM)"
	#if product is not None:
	#	return product
