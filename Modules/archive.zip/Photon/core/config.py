intels = ['github.com', 'facebook.com', 'instagram.com', 'youtube.com']
badTypes = ['png', 'jpg', 'jpeg', 'pdf', 'js', 'css', 'ico', 'bmp', 'svg', 'json', 'xml', 'xls', 'csv', 'docx']